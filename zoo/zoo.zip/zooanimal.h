#ifndef ZOOANIMAL_H
#define ZOOANIMAL_H
#include <iostream>
#include <string>
using namespace std;
class Masa
{
public:
	int godina;
	int tezina;
};
class ZooAnimal
{
public:
	// ZooAnimal(ZooAnimal& animal);
	ZooAnimal();
	ZooAnimal(string vrsta, string ime, int godRodjenja, int brojKaveza, int brojDnevnihObroka, int ocekivaniZivotniVijek);
	void promjenaBrObroka(string unos);
	void dodajMasu(int kilogrami, int godina);
	void udebljala();
	void ispisi_zivotinju();
	 // ~ZooAnimal();
	  ZooAnimal(const ZooAnimal& an);
	 

	//void unosZivotinje();
private:
	string vrsta;
	string ime;
	int godRodjenja;
	int brojKaveza;
	int brojDnevnihObroka;
	int ocekivaniZivotniVijek;
	Masa* masa;
};

#endif // ZOOANIMAL_H
